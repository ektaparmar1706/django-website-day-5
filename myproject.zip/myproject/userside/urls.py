from django.urls import path
from django.urls import path
from . import views

urlpatterns = [
    path('',views.home,name='home'),
    path('aboutus',views.about,name='aboutus'),
    path('contactus',views.contact,name='contactus'),
    path('login',views.login,name='login'),
    path('registration',views.registration,name='registration'),
    path('form',views.myform,name='myform'),
    path('formprocess',views.process,name='process'),
]